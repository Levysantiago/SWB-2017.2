Este arquivo contém o material para uma instância do attacklab.

Arquivos:

    ctarget

Binário Linux com a vulnerabilidade de injeção de código. Será utilizado
nas fases 1-3 da atividade.

    rtarget

Binário Linux com vulnerabilidade de programação orientada a retorno. Será
utilizada nas fases 4-5 da atividade.

     cookie.txt

Arquivo de texto contendo uma assinatura de 4 bytes necessária para esta
instância do laboratório.

     farm.c

Código fonte para o gadget farm presente nesta instância de rtarget. Você
pode compilar (utilize a flag -Og) e desmonte-a para buscar pelos gadgets.

     hex2raw

Programa utilitário para gerar uma sequência de bytes. Veja a documentação
da atividade laboratório.

