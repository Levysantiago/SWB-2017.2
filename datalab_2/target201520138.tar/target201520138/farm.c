/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_271(unsigned x)
{
    return x + 3231171416U;
}

unsigned addval_114(unsigned x)
{
    return x + 3351742792U;
}

void setval_448(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_113(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_469()
{
    return 2425510066U;
}

unsigned getval_337()
{
    return 3347925125U;
}

unsigned getval_159()
{
    return 2488799024U;
}

unsigned getval_118()
{
    return 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_243(unsigned *p)
{
    *p = 3531132553U;
}

unsigned getval_473()
{
    return 3285289393U;
}

void setval_397(unsigned *p)
{
    *p = 2428635452U;
}

unsigned getval_356()
{
    return 3527983753U;
}

void setval_425(unsigned *p)
{
    *p = 3247493513U;
}

unsigned getval_225()
{
    return 3286272328U;
}

unsigned getval_180()
{
    return 3526935049U;
}

unsigned addval_498(unsigned x)
{
    return x + 3286272840U;
}

unsigned addval_451(unsigned x)
{
    return x + 3286272328U;
}

void setval_321(unsigned *p)
{
    *p = 2430634313U;
}

unsigned getval_136()
{
    return 3531918984U;
}

unsigned getval_334()
{
    return 2497743176U;
}

unsigned addval_408(unsigned x)
{
    return x + 3536110217U;
}

void setval_339(unsigned *p)
{
    *p = 3281179017U;
}

unsigned getval_237()
{
    return 3531918977U;
}

void setval_307(unsigned *p)
{
    *p = 3380924873U;
}

void setval_414(unsigned *p)
{
    *p = 3375940233U;
}

unsigned addval_424(unsigned x)
{
    return x + 3223376281U;
}

void setval_412(unsigned *p)
{
    *p = 3536114057U;
}

void setval_254(unsigned *p)
{
    *p = 3677933193U;
}

unsigned addval_179(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_178()
{
    return 3682913929U;
}

void setval_481(unsigned *p)
{
    *p = 3676360328U;
}

void setval_411(unsigned *p)
{
    *p = 3252717896U;
}

void setval_160(unsigned *p)
{
    *p = 3372794505U;
}

unsigned addval_435(unsigned x)
{
    return x + 2425406088U;
}

void setval_285(unsigned *p)
{
    *p = 2425671305U;
}

unsigned addval_387(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_430()
{
    return 3375944137U;
}

unsigned getval_156()
{
    return 3373846153U;
}

unsigned getval_164()
{
    return 3281047945U;
}

void setval_471(unsigned *p)
{
    *p = 3281044121U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
